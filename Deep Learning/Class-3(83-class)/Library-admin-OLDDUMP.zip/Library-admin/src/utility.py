def input_is_valid(msg, start=0, end=None):
    while True:
        try:
            user_input = input(msg)
            if not user_input.isdecimal():
                raise ValueError("Input must be a decimal number.")
            user_input = int(user_input)
            if end is not None and not (start <= user_input <= end):
                raise ValueError(f"Input must be between {start} and {end}.")
            return user_input
        except ValueError as e:
            print(f"Invalid input: {e} Please try again.")
        