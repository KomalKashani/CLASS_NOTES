from src.admin import Admin
from src.utility import input_is_valid


class Manage:
    def __init__(self):
        self.admin = Admin()

    def print_menu(self):
        print("Program Menu Options:")
        options = [
            "1. Add a book",
            "2. Print all books",
            "3. Print books by prefix",
            "4. Add a user",
            "5. Borrow book",
            "6. Return book",
            "7. Print all users",
            "8. Print borrowed books by user",
        ]
        print('\n'.join(options))
        return self.get_user_choice(len(options))
    
    def get_user_choice(self, options_count):
        msg = f"Enter a number between 1 and {options_count}: \n"
        return input_is_valid(msg, 1, options_count)
    
    def add_book(self):
        book_id = input("Enter the book id: \n")
        book_name = input("Enter the book name: \n")
        book_quantity = input("Enter the book quantity: \n")
        self.admin.add_book(book_id, book_name, book_quantity)

    def print_all_books(self):
        print(self.admin.print_all_books())

    def search_book(self):
        query = input("Enter your book name query: \n")
        return self.admin.search_for_book(query)

    def add_user(self):
        user_id = input("Enter the user id: \n")
        user_name = input("Enter the user name: \n")
        self.admin.add_user(user_id, user_name)

    def borrow_book(self):
        user_name = input("Enter the user name: \n")
        book_name = input("Enter the book name: \n")
        self.admin.borrow_book(user_name, book_name)

    def return_book(self):
        user_name = input("Enter the user name: \n")
        book_name = input("Enter the book name: \n")
        self.admin.return_book(user_name, book_name)

    def print_all_users(self):
        print(self.admin.print_all_users())

    def print_borrowed_books_by_user(self):
        print(self.admin.print_borrowed_user_books())

    def run(self):
        while True:
            choice = self.print_menu()
            if choice == 1:
                self.add_book()
            elif choice == 2:
                self.print_all_books()
            elif choice == 3:
                self.search_book()
            elif choice == 4:
                self.add_user()
            elif choice == 5:
                self.borrow_book()
            elif choice == 6:
                self.return_book()
            elif choice == 7:
                self.print_all_users()
            elif choice == 8:
                self.print_borrowed_books_by_user()
                break
        

