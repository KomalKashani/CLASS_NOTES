from src.book_users import *

class Admin:
    def __init__(self):
        self.books = []
        self.users = {}

    def add_book(self, book_id, book_name, book_quantity):
        for book in self.books:
            if book.id == book_id:
                print(f"Book with id {book_id} already exists")
                return
        new_book = Book(book_id, book_name, book_quantity)
        self.books.append(new_book)
        print(f"Book {new_book.name} added successfully")

    def print_all_books(self):
        lst_of_books = []
        for book in self.books:
            lst_of_books.append(book.name)
        if not lst_of_books:
            print("No books found")
        else:
            print(lst_of_books)

    def search_for_book(self, query):
        found_books = [book.name for book in self.books if book.name[:len(query)].upper() == query.upper()]
        if not found_books:
            print("No books found")
        else:
            print(found_books)

    def add_user(self, user_id, user_name):
        for user in self.users:
            if user.id == user_id:
                print(f"User with id {user_id} already exists")
                return
        new_user = User(user_id, user_name)
        self.users[user_id] = new_user
        print(f"User {new_user.name} added successfully")

    def borrow_book(self, user_name, book_name):
        found_books = ''.join(self.search_for_book(book_name))
        user_found = False
        available_books = [book for book in self.books if book.name == found_books and book.quantity > 0]
        if not available_books:
            print("No available books found")
            return
        available_books[0].quantity -= 1
        for user, books in self.users.items():
            if user.name.lower() == user_name.lower():
                user_found = True
                books.append(available_books[0].name)
        if not user_found:
            print("User not found")
            return
        print(f"{user_name} borrowed {book_name}")

    def return_book(self, user_name, book_name):
        found_books = ''.join(self.search_for_book(book_name))
        user_found = False
        available_books = [book for book in self.books if book.name == found_books]
        if not available_books:
            print("Book not found")
            return
        available_books[0].quantity += 1
        for user, books in self.users.items():
            if user.name.lower() == user_name.lower():
                user_found = True
                books.remove(found_books)
        if not user_found:
            print("User not found")
            return
        return f'The user {user_name} returned {book_name}'
    
    def print_all_users(self):
        all_users = [user.name for user in self.users.values()]
        if all_users:
            for user in all_users:
                print(user, end=' ')
        else:
            print("No users found")

    def print_borrowed_user_books(self):
        users_found = [user for user in self.users if self.users[user] is not None]
        if users_found:
            for user in users_found:
                print(f' The user {user} borrowed the books: {self.users[user]}')
        else:
            print("No users found")
