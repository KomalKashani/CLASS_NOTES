from src.manage import Manage

if __name__ == "__main__":
    manage = Manage()
    manage.run()